library(rminer)
library(randomForest)
library(rpart.plot)
library(caTools)
library(caret)
library(mltools)
library(ade4)
library(data.table)
library(nnet)
library(dplyr)
library(e1071)
base=read.csv("C:/Users/andre/Desktop/OneDrive - Universidade do Minho/DataMining/tb/student-mat.csv", header = TRUE, sep = ";")

#Portugues
#base=read.csv("C:/Users/andre/Desktop/OneDrive - Universidade do Minho/DataMining/tb/student-por.csv", header = TRUE, sep = ";")


barplot(prop.table(table(base$G3)))
#------------------------DATA UNDERSTANDING-------------------------------------
print(base)
is.na(base) #ver missing values
sapply(base, function(x) sum(is.na(x))) #ver missing values resumido

#ver se todos os valores estão dentro do esperado
summary(base)

#ver outliers
boxplot(base$age, col = "blue") #idade 1 outlier (remover 22anos)
boxplot(base$absences, col = "blue") #nao se retirar
boxplot(base$G1, col = "blue") # 0outlier
boxplot(base$G2, col = "blue")# 1outlier (nao remover)

hist(base$G3, col = "blue", breaks = 20) #ver distribuicao



#Tornar atributos binarios em 0 e 1
base$school [base$school  == 'GP'] = 0
base$school [base$school  == 'MS'] = 1

base$sex[base$sex == 'F'] = 0
base$sex[base$sex == 'M'] = 1


base$address [base$address == 'U'] = 0
base$address [base$address  == 'R'] = 1


base$famsize [base$famsize == 'LE3'] = 0
base$famsize [base$famsize  == 'GT3'] = 1


base$Pstatus  [base$Pstatus == 'T'] = 0
base$Pstatus  [base$Pstatus  == 'A'] = 1


base$schoolsup [base$schoolsup == 'no'] = 0
base$schoolsup  [base$schoolsup  == 'yes'] = 1


base$famsup [base$famsup == 'no'] = 0
base$famsup  [base$famsup  == 'yes'] = 1


base$paid [base$paid == 'no'] = 0
base$paid  [base$paid  == 'yes'] = 1


base$activities [base$activities == 'no'] = 0
base$activities  [base$activities  == 'yes'] = 1


base$nursery [base$nursery == 'no'] = 0
base$nursery  [base$nursery  == 'yes'] = 1


base$higher [base$higher == 'no'] = 0
base$higher  [base$higher  == 'yes'] = 1


base$internet [base$internet == 'no'] = 0
base$internet  [base$internet  == 'yes'] = 1


base$romantic [base$romantic == 'no'] = 0
base$romantic  [base$romantic  == 'yes'] = 1



#base$school=as.numeric(base$school)
#base$address=as.numeric(base$address)
#base$famsize=as.numeric(base$famsize)
#base$Pstatus=as.numeric(base$Pstatus)
#base$schoolsup=as.numeric(base$schoolsup)
#base$activities=as.numeric(base$activities)
#base$sex=as.numeric(base$sex)
#base$famsup=as.numeric(base$famsup)
#base$nursery=as.numeric(base$nursery)
#base$higher=as.numeric(base$higher)
#base$internet=as.numeric(base$internet)
#base$romantic=as.numeric(base$romantic)
#base$paid=as.numeric(base$paid)

#---------------------------##AS-numeric##--------------------

cols.num <- c("school","sex","address","famsize","Pstatus","schoolsup",
              "famsup","paid","activities","nursery","higher","internet","romantic")
base[cols.num] <- sapply(base[cols.num],as.numeric)



ohe_feats = c("Mjob","Fjob","reason","guardian")
dummies = dummyVars(~ Mjob + Fjob + reason + guardian , data = base)
df_all_ohe =  as.data.frame(predict(dummies, newdata = base))
df_all_combined = cbind(base[,-c(which(colnames(base) %in% ohe_feats))],df_all_ohe)
base = as.data.frame(df_all_combined)




#standardization------------------------------
min_max <- function(x) {
  return ((x - mean(x)) / (sd(x)))
}

standardization <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

base$age=standardization(base$age)
base$Fedu=standardization(base$Fedu)
base$Medu=standardization(base$Medu)
base$traveltime=standardization(base$traveltime)
base$studytime=standardization(base$studytime)
base$failures=standardization(base$failures)
base$famrel=standardization(base$famrel)
base$freetime=standardization(base$freetime)
base$goout=standardization(base$goout)
base$Dalc=standardization(base$Dalc)
base$Walc=standardization(base$Walc)
base$health=standardization(base$health)
base$absences=standardization(base$absences)

#---------Definir-as-restantes-bases-de-dados-------------
#base2=base
#base_binary=base
#base3=base

#Criacao de base de dados com 5 valores
#base2$G3=cut(base$G3,c(-1,10,12,14,16,21),c(0,1,2,3,4))
#base2$G3=cut(base$G3,c(-1,10,12,14,16,21),c(5,4,3,2,1))
#Criacao de base binaria
#base_binary$G3[base$G3 < 10] = 0
#base_binary$G3[base$G3 >= 10] = 1



#-----------------------DATA PREPARATION----------------------------------------
#retirar outliers
base= base[base[, "age"] <22,]
summary(base$age) #verificando o maximo
#base2= base2[base2[, "age"] <22,]
#base_binary= base_binary[base_binary[, "age"] <22,]


#---------------------
### exploration of some rminer classification models: 
#--http://math.furman.edu/~dcs/courses/math47/R/library/randomForest/html/varImpPlot.html---
#Ver a importancia de cada atributo
set.seed(4543)
#data(base)
mtcars.rf <- randomForest(G3 ~ ., data=base, ntree=2000, keep.forest=FALSE,importance=TRUE)
varImpPlot(mtcars.rf)


#Retirar as coluna de G1 e G2 que sao muito preditivas
#base$G2 = NULL
#base$G1= NULL


set.seed(4543)
#(base)
mtcars.rf <- randomForest(G3 ~ ., data=base, ntree=2000, keep.forest=FALSE,importance=TRUE)
varImpPlot(mtcars.rf)

#-------------rearrange-data-------------

base=base %>% relocate(G3, .after = last_col())



#-------------Random-Forest-------------

g3=which(names(base)=="G3")
cat("output class:",class(base[,g3]),"\n")

# mining for randomForest, external 10-fold, 20 Runs (=60 fitted models)
M1=mining(G3~.,base,model="randomForest",method=c("kfold",10,123),Runs=20) #cortez2008using
m=mmetric(M1,metric=c("RMSE","MAE"))  
summary(m)






#-------------Naive--------------


M2=fit(G3~.,df_train,model="naive", task="class")
P2=predict(M2,df_test)

cat("predicted ACC:",round(mmetric(Y,P2,metric="ACC"),1),"\n")

print(mmetric(Y,P2,metric="ALL"))

plot(M2@object);text(M2@object)
rpart.plot(M2@object)


confusionMatrix(P2, Y)



#-------------Decision-Tree-------------


M3=fit(G3~.,df_train,model="dt", task="class")
P3=predict(M3,df_test)

cat("predicted ACC:",round(mmetric(Y,P3,metric="ACC"),1),"\n")

print(mmetric(Y,P3,metric="ALL"))

plot(M3@object);text(M3@object)
rpart.plot(M3@object)


confusionMatrix(P3, Y)

#-------------Nearest-Neighbor-------------

inputs=1:45
g3=which(names(base)=="G3")
cat("output class:",class(base[,g3]),"\n")

rmath=base[,c(inputs,g3)] # for easy use
y=rmath$g3 # target

# mining for randomForest, external 10-fold, 20 Runs (=60 fitted models)
M1=mining(G3~.,rmath,model="knn",method=c("kfold",10,123),Runs=20) #cortez2008using
m=mmetric(M1,metric="RMSE")  
summary(m)

summary(rmath)



#-------------SVM-------------

M5=fit(G3~.,df_train,model="svm", task="class",search = 'UD')
P5=predict(M5,df_test)

cat("predicted ACC:",round(mmetric(Y,P5,metric="ACC"),1),"\n")

print(mmetric(Y,P5,metric="ALL"))

plot(M5@object);text(M5@object)
rpart.plot(M5@object)


confusionMatrix(P5, Y)

#-------------MLP-------------

dataset_divide=sample.split(base_binary,SplitRatio=0.7)
df_train=base_binary[dataset_divide==TRUE, ]
df_test=base_binary[dataset_divide==FALSE, ]


Y=factor(df_test$G3)

M6=fit(G3~.,df_train,model="mlp",task="default",search = 'heuristic10')
P6=predict(M6,df_test)
P6=round(P6)
P6=factor(P6)
cat("predicted ACC:",round(mmetric(Y,P6,metric="ACC"),1),"\n")

print(mmetric(Y,P6,metric="ALL"))

plot(M6@object);text(M6@object)
rpart.plot(M6@object)



confusionMatrix(P6, Y)












