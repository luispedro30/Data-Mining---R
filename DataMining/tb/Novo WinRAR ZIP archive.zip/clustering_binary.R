library('fpc')
library('factoextra')
library(dplyr)
library('magrittr')
library(tidyverse)
library(broom)
library(caret)


set.seed(1234)

base=read.csv("C:/Users/andre/Desktop/OneDrive - Universidade do Minho/DataMining/tb/student-mat.csv", header = TRUE, sep = ";")
base= base[base[, "age"] <22,]
#base$G3=as.numeric(cut(base$G3,c(-1,10,12,14,16,21),c(5,4,3,2,1)))
#base$G2=as.numeric(cut(base$G2,c(-1,10,12,14,16,21),c(5,4,3,2,1)))
#base$G1=as.numeric(cut(base$G1,c(-1,10,12,14,16,21),c(5,4,3,2,1)))


base$G3[base$G3 < 10] = 0
base$G3[base$G3 >= 10] = 1
base$G2[base$G2 < 10] = 0
base$G2[base$G2 >= 10] = 1
base$G1[base$G1 < 10] = 0
base$G1[base$G1 >= 10] = 1

base$school [base$school  == 'GP'] = 0
base$school [base$school  == 'MS'] = 1

base$sex[base$sex == 'F'] = 0
base$sex[base$sex == 'M'] = 1


base$address [base$address == 'U'] = 0
base$address [base$address  == 'R'] = 1


base$famsize [base$famsize == 'LE3'] = 0
base$famsize [base$famsize  == 'GT3'] = 1


base$Pstatus  [base$Pstatus == 'T'] = 0
base$Pstatus  [base$Pstatus  == 'A'] = 1


base$schoolsup [base$schoolsup == 'no'] = 0
base$schoolsup  [base$schoolsup  == 'yes'] = 1


base$famsup [base$famsup == 'no'] = 0
base$famsup  [base$famsup  == 'yes'] = 1


base$paid [base$paid == 'no'] = 0
base$paid  [base$paid  == 'yes'] = 1


base$activities [base$activities == 'no'] = 0
base$activities  [base$activities  == 'yes'] = 1


base$nursery [base$nursery == 'no'] = 0
base$nursery  [base$nursery  == 'yes'] = 1


base$higher [base$higher == 'no'] = 0
base$higher  [base$higher  == 'yes'] = 1


base$internet [base$internet == 'no'] = 0
base$internet  [base$internet  == 'yes'] = 1


base$romantic [base$romantic == 'no'] = 0
base$romantic  [base$romantic  == 'yes'] = 1

ohe_feats = c("Mjob","Fjob","reason","guardian")
dummies = dummyVars(~ Mjob + Fjob + reason + guardian , data = base)
df_all_ohe =  as.data.frame(predict(dummies, newdata = base))
df_all_combined = cbind(base[,-c(which(colnames(base) %in% ohe_feats))],df_all_ohe)
base = as.data.frame(df_all_combined)

cols.num <- c("school","sex","address","famsize","Pstatus","schoolsup",
              "famsup","paid","activities","nursery","higher","internet","romantic")
base[cols.num] <- sapply(base[cols.num],as.numeric)

view(base)
base.features = base
base.features$G3= NULL
view(base.features)


#----------Pre-Processing-----------------
#missing values and standardizatiob

numdata = sapply(base.features, is.numeric) #seperate numeric variables
mydata = base.features[ , numdata] #keep only numeric variables


standardization <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

#create a normalization function

#for_clust_data  = as.data.frame(lapply(mydata, standardization)) #normalize data , keep only 6 variables
#for_clust_data  = as.data.frame(lapply(mydata[ ,c(1,5,6,13,14,15)], standardization)) 
for_clust_data  = as.data.frame(lapply(mydata[ ,c(3,26,27,28)], standardization))

km1 = kmeans(for_clust_data, 2, nstart=100)
km1$cluster#vector of clusters
km1$size

table(base$G3,km1$cluster) #comparation
plot(base[c("G1","G2")],col=km1$cluster)
plot(base[c("G1","G2")],col=base$G3)

p1 = fviz_cluster(km1, geom = "point", data = for_clust_data) + ggtitle("k = 2")
plot(p1)
