library(rminer)
library(randomForest)
library(rpart.plot)
library(caTools)
library(caret)
library(mltools)
library(ade4)
library(data.table)
library(nnet)
library(arules)

base=read.csv("C:/Users/andre/Desktop/OneDrive - Universidade do Minho/DataMining/tb/student-mat.csv", header = TRUE, sep = ";")
#Portugues
#base=read.csv("C:/Users/andre/Desktop/OneDrive - Universidade do Minho/DataMining/tb/student-por.csv", header = TRUE, sep = ";")
#------------------------DATA UNDERSTANDING------------------------------------


baseAR=base

#Remove age
baseAR$age=NULL

#Criacao de base binaria
baseAR$G3[base$G3 < 10] = "fail"
baseAR$G3[base$G3 >= 10] = "pass"
baseAR$G2[base$G2 < 10] = "fail"
baseAR$G2[base$G2 >= 10] = "pass"
baseAR$G1[base$G1 < 10] = "fail"
baseAR$G1[base$G1 >= 10] = "pass"

baseAR = as.data.frame(sapply(colnames(baseAR),function(name){ paste(name,baseAR[,name],sep="_")}))


write.csv(baseAR,"C:/Users/andre/Desktop/OneDrive - Universidade do Minho/DataMining/tb/baseAR.csv", row.names = FALSE)

baseAR=read.transactions("C:/Users/andre/Desktop/OneDrive - Universidade do Minho/DataMining/tb/baseAR.csv", header = TRUE, sep = ",",rm.duplicates = TRUE)

rules1<-apriori(baseAR,parameter = list(minlen=2, maxlen=4, supp=0.2, conf=0.8), 
                appearance = list(rhs=c("G3_pass"), default="lhs"),)
rules_sort = sort(rules1, by="support")
inspect(rules_sort)


par1=list(support=0.006,confidence=0.25,minlen=2)
grules=apriori(base,parameter=par1)
## set of 463 rules
inspect(grules)
# best support rules
inspect(sort(grules,by="support")[1:10])
# best lift rules
inspect(sort(grules,by="lift")[1:10])

















